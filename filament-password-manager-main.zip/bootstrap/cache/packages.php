<?php return array (
  'akaunting/laravel-money' => 
  array (
    'providers' => 
    array (
      0 => 'Akaunting\\Money\\Provider',
    ),
  ),
  'awcodes/filament-table-repeater' => 
  array (
    'aliases' => 
    array (
      'FilamentTableRepeater' => 'Awcodes\\FilamentTableRepeater\\Facades\\FilamentTableRepeater',
    ),
    'providers' => 
    array (
      0 => 'Awcodes\\FilamentTableRepeater\\FilamentTableRepeaterServiceProvider',
    ),
  ),
  'bezhansalleh/filament-addons' => 
  array (
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentAddons\\FilamentAddonsServiceProvider',
    ),
  ),
  'bezhansalleh/filament-exceptions' => 
  array (
    'aliases' => 
    array (
      'FilamentExceptions' => 'BezhanSalleh\\FilamentExceptions\\Facades\\FilamentExceptions',
    ),
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentExceptions\\FilamentExceptionsServiceProvider',
    ),
  ),
  'bezhansalleh/filament-language-switch' => 
  array (
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentLanguageSwitch\\FilamentLanguageSwitchServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
  ),
  'marjose123/filament-lockscreen' => 
  array (
    'aliases' => 
    array (
      'FilamentLockscreen' => 'lockscreen\\FilamentLockscreen\\Facades\\FilamentLockscreen',
    ),
    'providers' => 
    array (
      0 => 'lockscreen\\FilamentLockscreen\\FilamentLockscreenServiceProvider',
    ),
  ),
  'marjose123/filament-no-connection' => 
  array (
    'aliases' => 
    array (
      'FilamentNoConnection' => 'MarJose123\\FilamentNoConnection\\Facades\\FilamentNoConnection',
    ),
    'providers' => 
    array (
      0 => 'MarJose123\\FilamentNoConnection\\FilamentNoConnectionServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'phpsa/filament-password-reveal' => 
  array (
    'providers' => 
    array (
      0 => 'Phpsa\\FilamentPasswordReveal\\FilamentPasswordRevealProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
  ),
  'shuvroroy/filament-spatie-laravel-backup' => 
  array (
    'providers' => 
    array (
      0 => 'ShuvroRoy\\FilamentSpatieLaravelBackup\\FilamentSpatieLaravelBackupServiceProvider',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-backup' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Backup\\BackupServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
  ),
  'spatie/laravel-signal-aware-command' => 
  array (
    'aliases' => 
    array (
      'Signal' => 'Spatie\\SignalAwareCommand\\Facades\\Signal',
    ),
    'providers' => 
    array (
      0 => 'Spatie\\SignalAwareCommand\\SignalAwareCommandServiceProvider',
    ),
  ),
  'z3d0x/filament-logger' => 
  array (
    'aliases' => 
    array (
      'FilamentLogger' => 'Z3d0X\\FilamentLogger\\Facades\\FilamentLogger',
    ),
    'providers' => 
    array (
      0 => 'Z3d0X\\FilamentLogger\\FilamentLoggerServiceProvider',
    ),
  ),
);