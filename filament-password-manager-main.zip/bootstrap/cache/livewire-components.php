<?php return array (
  'auth.complete-account' => 'App\\Http\\Livewire\\Auth\\CompleteAccount',
  'auth.login' => 'App\\Http\\Livewire\\Auth\\Login',
);