<div wire:poll.<?php echo e(config('filament-spatie-laravel-backup.polling.interval') ?? '4s'); ?>>
	<?php echo e($this->table); ?>

</div>
<?php /**PATH C:\xampp\htdocs\New folder\filament-password-manager-main\filament-password-manager-main\vendor\shuvroroy\filament-spatie-laravel-backup\src\/../resources/views/components/backup-destination-status-list-records.blade.php ENDPATH**/ ?>