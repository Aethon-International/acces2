<div <?php echo e($attributes->class(['filament-dropdown-list p-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\New folder\filament-password-manager-main\filament-password-manager-main\vendor\filament\support\src\/../resources/views/components/dropdown/list/index.blade.php ENDPATH**/ ?>