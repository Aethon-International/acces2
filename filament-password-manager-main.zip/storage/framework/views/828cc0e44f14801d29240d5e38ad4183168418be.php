<div <?php echo e($attributes->merge($getExtraAttributes())); ?>>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH C:\xampp\htdocs\New folder\filament-password-manager-main\filament-password-manager-main\vendor\filament\forms\src\/../resources/views/components/group.blade.php ENDPATH**/ ?>