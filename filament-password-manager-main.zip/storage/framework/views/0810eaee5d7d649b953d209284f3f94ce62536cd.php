<div wire:offline>
    <section class="internet-connection">
        <div class="internet-connection__alert">
            <span class="internet-connection__icon h-icon"></span>
            <span class="internet-connection__text">Server connection timeout</span>
        </div>
    </section>
</div>
<?php /**PATH C:\xampp\htdocs\New folder\filament-password-manager-main\filament-password-manager-main\resources\views/vendor/filament-no-connection/livewire/offline.blade.php ENDPATH**/ ?>