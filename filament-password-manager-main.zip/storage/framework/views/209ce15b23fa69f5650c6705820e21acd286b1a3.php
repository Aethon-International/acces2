<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('Offline')->html();
} elseif ($_instance->childHasBeenRendered('SRZ1qmY')) {
    $componentId = $_instance->getRenderedChildComponentId('SRZ1qmY');
    $componentTag = $_instance->getRenderedChildComponentTagName('SRZ1qmY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SRZ1qmY');
} else {
    $response = \Livewire\Livewire::mount('Offline');
    $html = $response->html();
    $_instance->logRenderedChild('SRZ1qmY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\xampp\htdocs\New folder\filament-password-manager-main\filament-password-manager-main\storage\framework\views/2775b34d9b7b65dddc5c153a2f513811645d128c.blade.php ENDPATH**/ ?>