<td
    <?php echo e($attributes->class(['filament-tables-reorder-cell w-4 px-4 whitespace-nowrap'])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\xampp\htdocs\New folder\filament-password-manager-main\filament-password-manager-main\vendor\filament\tables\src\/../resources/views/components/reorder/cell.blade.php ENDPATH**/ ?>